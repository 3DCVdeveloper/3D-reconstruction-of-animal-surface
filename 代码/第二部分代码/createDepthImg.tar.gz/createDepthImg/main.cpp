/*****************************************************************************
*                                                                            *
*  OpenNI 2.x Alpha                                                          *
*  Copyright (C) 2012 PrimeSense Ltd.                                        *
*                                                                            *
*  This file is part of OpenNI.                                              *
*                                                                            *
*  Licensed under the Apache License, Version 2.0 (the "License");           *
*  you may not use this file except in compliance with the License.          *
*  You may obtain a copy of the License at                                   *
*                                                                            *
*      http://www.apache.org/licenses/LICENSE-2.0                            *
*                                                                            *
*  Unless required by applicable law or agreed to in writing, software       *
*  distributed under the License is distributed on an "AS IS" BASIS,         *
*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  *
*  See the License for the specific language governing permissions and       *
*  limitations under the License.                                            *
*                                                                            *
*****************************************************************************/
#include <OpenNI.h>
#include "Viewer.h"
#include <stdio.h>
#include <iostream>
#include <highgui.h>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
using namespace std;
using namespace openni;
//#include "OniSampleUtilities.h"
#define SAMPLE_READ_WAIT_TIMEOUT 2000 //2000ms
int wasKeyboardHit();

int main(int argc, char** argv)
{
	openni::Status rc = openni::STATUS_OK;
	openni::Status rc_d = openni::STATUS_OK;
	openni::Device device;
	openni::VideoStream depth, color;
	const char* deviceURI = openni::ANY_DEVICE;

	rc = openni::OpenNI::initialize();

	printf("After initialization:\n%s\n", openni::OpenNI::getExtendedError());

	rc = device.open(deviceURI);
	if (rc != openni::STATUS_OK)
	{
		printf("SimpleViewer: Device open failed:\n%s\n", openni::OpenNI::getExtendedError());
		openni::OpenNI::shutdown();
		return 1;
	}

	rc = depth.create(device, openni::SENSOR_DEPTH);
	if (rc == openni::STATUS_OK)
		rc = depth.start();


	openni::VideoFrameRef frameDepth;

	openni::DepthPixel* pDepth;
		
	cout<<"stream start, press any key to stop..."<<endl;

    	VideoStream* streams[] = {&depth, &color};

	//while (!wasKeyboardHit())
	for(int i=0;i<10;++i)
	{

	    int depthstream = -1;

	    rc = OpenNI::waitForAnyStream(streams, 2, &depthstream, SAMPLE_READ_WAIT_TIMEOUT);
	    if (rc != STATUS_OK)
	    {
		printf("Wait failed! (timeout is %d ms)\n%s\n", SAMPLE_READ_WAIT_TIMEOUT, OpenNI::getExtendedError());
		continue;
	    }
		cout<<"waitForAnyStream finished, press any key to stop..."<<endl;

	    //get color frame
		rc_d = depth.readFrame(&frameDepth);

	    cout<<"read Frame finished, press any key to stop..."<<endl;

	    if (rc != STATUS_OK || rc_d != STATUS_OK)
	    {
		printf("Read failed!\n%s\n", OpenNI::getExtendedError());
		continue;
	    }
	    //check if the frame format is rgb888 frame format

	    int middleIndex = (frameDepth.getHeight() + 1)*frameDepth.getWidth() / 2;
		pDepth = (DepthPixel*)frameDepth.getData();
	    //print the r g b value of the middle pixel of the frame

		cout  << pDepth[middleIndex]  <<endl;

		// 将深度数据转换成OpenCV格式
		const cv::Mat mImageDepth( frameDepth.getHeight(), frameDepth.getWidth(), CV_16UC1, (void*)frameDepth.getData());
		// 为了让深度图像显示的更加明显一些，将CV_16UC1 ==> CV_8U格式
		cv::Mat mScaledDepth;
			int iMaxDepth = depth.getMaxPixelValue();
		mImageDepth.convertTo( mScaledDepth, CV_8U, 255.0 / iMaxDepth );
		// 深度图像
		cv::imwrite( "DepthImage.png", mScaledDepth );
	}

	return 0;
}


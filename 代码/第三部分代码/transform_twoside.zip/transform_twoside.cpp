#include <iostream>
#include <string>
#include <pcl/io/ply_io.h>
#include <pcl/registration/icp.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/console/time.h>   // TicToc
#include <pcl/common/common.h>  
#include <pcl/common/angles.h>  
#include <pcl/common/transforms.h>  
#include <pcl/point_cloud.h>  
#include <pcl/point_types.h>  
#include <pcl/io/pcd_io.h>  
#include <pcl/registration/transformation_estimation_svd.h>  

typedef pcl::PointXYZRGB PointT;
typedef pcl::PointCloud<PointT> PointCloudT;
using namespace pcl;

int
main(int argc,
    char* argv[])
{
    // The point clouds we will be using
    PointCloudT::Ptr cloud_in(new PointCloudT);  // Original point cloud
    PointCloudT::Ptr cloud_in2(new PointCloudT);  // Transformed point cloud
    PointCloudT::Ptr cloud_icp(new PointCloudT);  // ICP output point cloud

    PointCloudT::Ptr corrspond_in(new PointCloudT);  // Original point cloud
    PointCloudT::Ptr corrspond_out(new PointCloudT);  // Transformed point cloud
    PointCloudT::Ptr show_transformed_clouds(new PointCloudT);

    PointCloudT::Ptr cloud_in3(new PointCloudT);

    std::mutex cloud_mutex_;

    // Checking program arguments
    if (argc < 3)
    {
        printf("Usage :\n");
        printf("\t\t%s file.ply number_of_ICP_iterations\n", argv[0]);
        PCL_ERROR("Provide one ply file.\n");
        return (-1);
    }

    pcl::console::TicToc time;
    time.tic();
    if (pcl::io::loadPLYFile(argv[1], *cloud_in) < 0)
    {
        PCL_ERROR("Error loading cloud %s.\n", argv[1]);
        return (-1);
    }
    if (pcl::io::loadPLYFile(argv[2], *cloud_in2) < 0)
    {
        PCL_ERROR("Error loading cloud %s.\n", argv[2]);
        return (-1);
    }
    if (pcl::io::loadPLYFile(argv[3], *cloud_in3) < 0)
    {
        PCL_ERROR("Error loading cloud %s.\n", argv[2]);
        return (-1);
    }
    *cloud_in2 += *cloud_in3;
    *cloud_in3 = *cloud_in2;
    std::cout << "\nLoaded file " << argv[1] << " (" << cloud_in->size() << " points) in " << time.toc() << " ms\n" << std::endl;

    // Defining a rotation matrix and translation vector
    Eigen::Matrix4d transformation_matrix = Eigen::Matrix4d::Identity();

    // Executing the transformation
    PointT point_in_1(0.037176, -0.080071, 1.631000, 0, 0, 0);
    PointT point_in_2(0.042501, -0.146096, 1.515000, 0, 0, 0);
    PointT point_in_3(0.170003, -0.140784, 1.515000, 0, 0, 0);
    PointT point_in_4(0.163002, -0.071492, 1.631000, 0, 0, 0);
    corrspond_in->push_back(point_in_1);
    corrspond_in->push_back(point_in_2);
    corrspond_in->push_back(point_in_3);
    corrspond_in->push_back(point_in_4);

    PointT point_in_5(-0.076095, -0.331555, 1.550000, 0, 0, 0);
    PointT point_in_6(-0.043737, -0.274085, 1.663000, 0, 0, 0);
    PointT point_in_7(-0.167310, -0.274867, 1.704000, 0, 0, 0);
    PointT point_in_8(-0.200217, -0.325352, 1.586000, 0, 0, 0);
    corrspond_out->push_back(point_in_5);
    corrspond_out->push_back(point_in_6);
    corrspond_out->push_back(point_in_7);
    corrspond_out->push_back(point_in_8);

    //  pcl::transformPointCloud(*corrspond_in, *corrspond_out, transformation_matrix);
    cout << corrspond_in->size() << endl;
    cout << corrspond_out->size() << endl;
    //利用SVD方法求解变换矩阵  
    pcl::registration::TransformationEstimationSVD<PointT, PointT> TESVD;
    pcl::registration::TransformationEstimationSVD<PointT, PointT>::Matrix4 transformation2;
    TESVD.estimateRigidTransformation(*corrspond_in, *corrspond_out, transformation2);

    cout << transformation2 << endl;

    pcl::transformPointCloud(*cloud_in, *show_transformed_clouds, transformation2);
    *show_transformed_clouds += *cloud_in2;

    pcl::PCDWriter writer;
    writer.write("registered_final2.pcd", *show_transformed_clouds, false);
    writer.write("cloud_icp_2_rgb.pcd", *cloud_in2, false);

    pcl::PLYWriter writer2;
    writer2.write("registered_final2.ply", *show_transformed_clouds, false);
    writer2.write("cloud_icp_2_rgb.ply", *cloud_in2, false);

    cout << "registered" << endl; 

    // Display the visualiser

    return (0);
}

points=read_ply('pig_orbbec.ply');
landmarkIdxs=load('orbbec_LandmarkIdxs_2.txt');

% points=read_ply('1_pig_sup_2.ply');
% landmarkIdxs=load('1_pig_sup_2_landMark.txt');

   
% landmarkIdxs=[241;2068;5916];
% landmarkIdxs=pig_idxAbove;
landmark=points(landmarkIdxs,:);
% landmark=landmark(27,:);

labels = cell(size(landmark,1),1);
for i = 1:length(labels)
    labels{i} = num2str(i);
end

% labels = labels(landmarkIdxs);

plot3(landmark(:,1),landmark(:,2),landmark(:,3),'r*','markerSize',12);hold on;
text(landmark(:,1),landmark(:,2),landmark(:,3),labels); hold on;
plot3(points(:,1),points(:,2),points(:,3),'b.','MarkerSize',2); hold on;


axis equal;

环境配置
    首先请阅读Leonid Pishchulin等人提供的文档：setup_windows.pdf和README.md
	本程序只在windows系统下做过测试，建议先按照setup_windows.pdf配置好环境，然后阅读README.md更改一些设置，例如matlab的安装路径等，使其能够运行。
	
	
运行
1. Start matlab
2. Edit file `fitting/expParams.m`
   	1) point `p.rootDir` to the full path to the source code directory
3. Run `test`
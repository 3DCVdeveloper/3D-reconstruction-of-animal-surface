function testFitMesh(scanFilenames,landmarksScanFilename,expidx)
fprintf('pigFitMesh()\n');

% scanFilenames = {'scan.ply'};
% landmarksFilenames = {'scan.lnd'};
% expidx = 1;

if (ischar(expidx))
    expidx = str2double(expidx);
end

p = expParams(expidx);

if (~exist(p.fitDir,'dir'))
    mkdir(p.fitDir);
end

% remove mosek from matlab path, if any
s = which('quadprog.m');
if ~isempty(strfind(s,'mosek')) && ~isdeployed
    new_path = removeMosek();
    matlabpath(new_path);
end

% create directories for fitting results
saveDir = cell(length(scanFilenames),1);
initDir = cell(length(scanFilenames),1);
for i = 1:length(scanFilenames)
    [~,nameScan] = fileparts(scanFilenames{i});
    saveDir{i} = [p.fitDir '/' nameScan];
    if (~exist(saveDir{i}, 'dir'))
        mkdir(saveDir{i});
    end
    initDir{i} = [p.initDir '/' nameScan];
    assert(exist(initDir{i},'dir')>0);
end

% print parameters
fprintf('scanFilename: %s\n',scanFilenames{1});
fprintf('landmarksFilename: %s\n',landmarksScanFilename{1});
fprintf('saveDir: %s\n',saveDir{1});
fprintf('modelDir: %s\n',p.modelInDir);
fprintf('initDir: %s\n',p.initDir);
fprintf('nPCA: %d\n',p.nPCA);


p.landmarksSM=repmat(p.landmarksSM, 1,length(scanFilenames));%����ģ�͵�landmarks�ļ�·����ʹ����������san��landmarks�ļ�����һ��
% read landmarks,prepare scan
[scan,template] = test_ReadLandMarksAll(scanFilenames,landmarksScanFilename,p.landmarksSM,expidx);

% prepare template
[pointsTem,~,facesTem] = read_ply(p.pathSM);
for i = 1:length(template)
    template(i).faces = facesTem;
   
    % center meanShape
    pointsTem = pointsTem - repmat(mean(pointsTem),size(pointsTem,1),1);
    template(i).points = pointsTem*10;
end

assert(length(scan) == length(template));

for i=1:length(scan)
    % save subsampled scan
    points = scan(i).points;
    faces = scan(i).faces;
    template(i).idxsUse = [];
    template(i).poseParamsIgnoreIdxs = []; % ignore wrist rotations
   % normals = getNormals1Face(scan(i).pointsIdxs,scan(i).faces,scan(i).normals);
    normals = scan(i).normals;
    save([saveDir{i} '/scan'],'points','normals');
end


for i=1:length(scan)
    fprintf('register1++++++++++: %d\n',i);
    register(scan(i),template(i),saveDir{i},p.modelInDir,p.nrdWidx,initDir{i});
    fprintf('complete++++++++++: %d\n',i);
end


% if (length(scan) == 1)
%     % register the scan
%     template = register(scan,template,saveDir{1},p.modelInDir,p.bInit,p.nrdWidx,initDir{1});
% else
%     % joint optimization over shape parameters when multiple scans available
%     template = registerJoint(scan,template,saveDir,modelDir,initDir);
% end    
close all;

end
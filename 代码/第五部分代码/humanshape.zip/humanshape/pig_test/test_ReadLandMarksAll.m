function [scan,template,bIsBad] = test_ReadLandMarksAll(scanFilenames,landmarksScanFilenames,landmarksSMFilenames,expidx)

scan.landmarks = [];

for i = 1:length(scanFilenames)
    %% read scan
    [~,~,ext] = fileparts(scanFilenames{1});
    if (strcmp(ext,'.obj'))
        [pointsAllScan,facesScan] = read_obj(scanFilenames{i});
        confidenceScan = ones(size(pointsAllScan,1),1);
    elseif (strcmp(ext,'.mat'))
        load(scanFilenames{i});
        assert(exist('points','var')>0);
        pointsAllScan = points;
        if (exist('faces','var') == 0)
            faces = zeros(0,3);
        end
        facesScan = faces;
        confidenceScan = ones(size(pointsAllScan,1),1);
    else
        [pointsAllScan,confidenceScan,facesScan] = read_ply(scanFilenames{i});
    end
    
    pointsAllScan = m2mm(pointsAllScan,expidx);
    
%     %% subsample scan
% %     nPointsSample = 16000;
%     nPointsSample = min(6449*3,size(pointsAllScan,1));
%     fprintf('nPointsSample: %d/%d\n',nPointsSample,size(pointsAllScan,1));
%     
% %     if (i == 1)
%         pointsIdxsScan = randperm(size(pointsAllScan,1),nPointsSample);
% %     end
%     
%     points = pointsAllScan(pointsIdxsScan(1:nPointsSample),:);
    
    %% compute normals
    [normalsScan,curvature] = findPointNormals(pointsAllScan,[],[0,0,0],true);
%     normalsScan = getNormals(pointsAllScan,facesScan);

     scan(i).points = pointsAllScan;
     scan(i).normals = normalsScan;
     scan(i).faces = facesScan;
     scan(i).confidence = confidenceScan;
     scan(i).pointsIdxs = 1:length(scan(i).points);
%      
%      n_sample=100;
%      x=scan.points(:,1);
%      x=x(1:n_sample:end);
%      y=scan.points(:,2);
%      y=y(1:n_sample:end);
%      z=scan.points(:,3);
%      z=z(1:n_sample:end);
%      u=normalsScan(:,1);
%      u=u(1:n_sample:end);
%      v=normalsScan(:,2);
%      v=v(1:n_sample:end);
%      w=normalsScan(:,3);
%      w=w(1:n_sample:end);
%      quiver3(x,y,z,u,v,w);
%      hold off
% quiver3(pointsAllScan(:,1),pointsAllScan(:,2),pointsAllScan(:,3),normalsScan(:,1),normalsScan(:,2),normalsScan(:,3));
% hold off
    %% readLandMarksAll
    landmarksIdxs=load(landmarksSMFilenames{i});
    template(i).landmarksIdxs = landmarksIdxs;

%     landmarks = landmarks(1:nLandmarks,:);
    %landmarks = m2mm(landmarks);
    scan_landmarksIdxs = load(landmarksScanFilenames{i});
    landmarks=scan(i).points(scan_landmarksIdxs,:);
    scan(i).landmarks = landmarks;
    scan(i).landmarkIdxs = find(~isnan(scan(i).landmarks(:,1)) & ~isnan(template(i).landmarksIdxs));
end

end
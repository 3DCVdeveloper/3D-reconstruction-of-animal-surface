function  show_normal(scan,id)
     n_sample=100;
     x=scan.points(:,1);
     x=x(1:n_sample:end);
     y=scan.points(:,2);
     y=y(1:n_sample:end);
     z=scan.points(:,3);
     z=z(1:n_sample:end);
     if(id==1)
         u=scan.normals1face(:,1);
         v=scan.normals1face(:,2);
         w=scan.normals1face(:,3);
     else
         u=scan.normals(:,1);
         v=scan.normals(:,2);
         w=scan.normals(:,3);
     end
     
     u=u(1:n_sample:end);
     v=v(1:n_sample:end);
     w=w(1:n_sample:end);
     
%      sensorCenter = [0,0,0];
%      for k = 1 : numel(x)
%          p1 = sensorCenter - [x(k),y(k),z(k)];
%          p2 = [u(k),v(k),w(k)];
%          % Flip the normal vector if it is not pointing towards the sensor.
%          angle = atan2(norm(cross(p1,p2)),p1*p2');
%          if angle > pi/2 || angle < -pi/2
%              u(k) = -u(k);
%              v(k) = -v(k);
%              w(k) = -w(k);
%          end
%      end
%      
     
     h=quiver3(x,y,z,u,v,w);
     set(h,'maxheadsize',3,'Color', 'r');
     hold on
     plot3(0,0,0,'y*','MarkerSize',12);
     plot3(scan.points(:,1),scan.points(:,2),scan.points(:,3),'b.','MarkerSize',2); hold on;
     axis equal;
     hold off
end
     
if (~isdeployed)
    addpath([pwd '/external/lbfgsb-for-matlab/']);
    addpath([pwd '/shapemodel/']);
    addpath([pwd '/fitting/']);
    addpath([pwd '/learning/']);
    addpath([pwd '/evaluation/']);
    addpath([pwd '/evaluation/statQuality/']);
    addpath([pwd '/pig_test/']);
    addpath([pwd '/pig_test/orbbec_test/']);
end

/**
    This file is part of the implementation of the 3D human shape model as described in the paper:

    Leonid Pishchulin, Stefanie Wuhrer, Thomas Helten, Christian Theobalt and Bernt Schiele
    Building Statistical Shape Spaces for 3D Human Modeling
    ArXiv, March 2015

    Please cite the paper if you are using this code in your work.
    
    Contributors: Arjun Jain, Juergen Gall, Leonid Pishchulin.
    This code also uses open source functionality for matrix operations by Thomas Brox.

    The code may be used free of charge for non-commercial and
    educational purposes, the only requirement is that this text is
    preserved within the derivative work. For any other purpose you
    must contact the authors for permission. This code may not be
    redistributed without permission from the authors.
*/

#ifndef __ONLY_DEFINES__
#define __ONLY_DEFINES__

#define STEP_SIZE 10.0
#define STEP_SIZE_ROT 200.0

#define NO_OF_EIGENVECTORS 20
#define NO_SEMANTIC_PARAMS 6
#define NO_IMAGE_PARTS 8

#endif //__ONLY_DEFINES__

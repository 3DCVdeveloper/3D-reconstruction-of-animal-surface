function [ landmarks ] = readLandmarkXML( filename )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
xmlDoc = xmlread(filename);
name_array = xmlDoc.getElementsByTagName('point');

n=name_array.getLength;
landmarks=[];
for i=0:n-1
    name = name_array.item(i);
    xyz={};
    for j = 2:4
        m =char(name.getAttributes.item(j).getValue);
        m=str2num(m);
        xyz=[xyz;m];
    end
    xyz=cell2mat(xyz);
    xyz=reshape(xyz,1,3);
    landmarks = [landmarks; xyz];
end

end

